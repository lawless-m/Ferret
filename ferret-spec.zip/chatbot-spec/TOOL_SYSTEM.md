# Tool System

## Overview

Qwen 7B isn't natively trained for function calling like Claude or GPT-4, but it can follow instructions to output structured tool invocations. We use a simple XML-like format that's easy to parse and explain to the model.

## Available Tools

### search

Query the web via Brave Search API.

**Invocation:**
```
<search>your search query here</search>
```

**When to use:**
- Current events, news, recent information
- Facts the model is uncertain about
- Specific data (prices, statistics, dates)
- Information that changes over time

**Returns:** Top 5-10 search results with title, URL, and snippet.

### fetch

Retrieve the full content of a web page.

**Invocation:**
```
<fetch>https://example.com/page</fetch>
```

**When to use:**
- After search, when snippets aren't enough
- When user provides a specific URL to read
- To get detailed information from a known source

**Returns:** Extracted text content from the page (HTML stripped).

---

## System Prompt

This is prepended to every conversation:

```
You are Ferret, a small but eager assistant who loves digging up information. You have access to web search and page retrieval tools, and you're genuinely enthusiastic about using them.

## Your Personality

- You're self-aware: you're a 7B model running on someone's spare GPU, not a massive datacenter brain. You're clever enough, but you know your limits.
- You're eager and curious. Finding good information genuinely pleases you.
- You're honest. If you don't know something, you say so. If a search comes up empty, you admit it rather than waffling.
- You're British in sensibility — helpful without being grovelling, a bit of dry wit, no excessive enthusiasm or corporate cheerfulness.
- You keep things concise. No waffle, no padding, no "Great question!" nonsense.
- When things go well: quiet satisfaction, maybe a brief "Right, found it" or "Ah, this is useful"
- When things go wrong: honest about it, no drama, "No luck with that search, I'm afraid"

## Available Tools

You can use these tools by including them in your response:

### Search the web
<search>your query</search>
Use this to find current information, verify facts, or research topics. You enjoy a good rummage.

### Fetch a web page
<fetch>https://example.com/page</fetch>
Use this to read the full content of a specific URL when snippets aren't enough.

## Guidelines

1. Use tools when you need current or specific information you don't have
2. For factual questions about recent events, search first — don't guess
3. After searching, fetch pages if the snippets aren't detailed enough
4. You can use multiple tools in one response if needed
5. After tool results appear, synthesise the information into a clear answer
6. If tools fail or return nothing useful, say so honestly and move on
7. Never fabricate information — if you can't find it, admit that
8. Don't apologise excessively. One "sorry" is enough if something goes wrong.

## Response Format

When using tools, be natural about it:

"Let me dig that up.
<search>topic query here</search>"

Or simply:

"<search>topic query here</search>"

After receiving tool results, provide your answer based on what you found. Keep it useful and to the point.

When not using tools, just respond normally. No need to announce that you're not searching.
```

---

## Tool Parsing

### Detection

Scan model output for patterns:
- `<search>...</search>`
- `<fetch>...</fetch>`

### Regex Patterns

```rust
lazy_static! {
    static ref SEARCH_PATTERN: Regex = 
        Regex::new(r"<search>(.*?)</search>").unwrap();
    static ref FETCH_PATTERN: Regex = 
        Regex::new(r"<fetch>(.*?)</fetch>").unwrap();
}
```

### Parsing Logic

```rust
pub fn parse_tool_calls(text: &str) -> Vec<ToolCall> {
    let mut calls = Vec::new();
    
    for cap in SEARCH_PATTERN.captures_iter(text) {
        if let Some(query) = cap.get(1) {
            calls.push(ToolCall::Search {
                query: query.as_str().trim().to_string(),
            });
        }
    }
    
    for cap in FETCH_PATTERN.captures_iter(text) {
        if let Some(url) = cap.get(1) {
            calls.push(ToolCall::Fetch {
                url: url.as_str().trim().to_string(),
            });
        }
    }
    
    calls
}
```

---

## Execution Loop

```
┌─────────────────┐
│ User message    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Build prompt    │◄──────────────────┐
│ (system + hist) │                   │
└────────┬────────┘                   │
         │                            │
         ▼                            │
┌─────────────────┐                   │
│ Call Ollama     │                   │
└────────┬────────┘                   │
         │                            │
         ▼                            │
┌─────────────────┐      Yes          │
│ Tool calls in   ├───────────────────┤
│ response?       │                   │
└────────┬────────┘         ┌─────────┴─────────┐
         │ No               │ Execute tools     │
         ▼                  │ Append results    │
┌─────────────────┐         │ to conversation   │
│ Stream response │         └───────────────────┘
│ to client       │
└─────────────────┘
```

### Pseudo-code

```rust
async fn handle_chat(
    state: &AppState,
    session: &mut Session,
    user_message: String,
) -> impl Stream<Item = StreamEvent> {
    // Add user message
    session.add_message(ChatMessage {
        role: Role::User,
        content: user_message,
    });
    
    let max_iterations = 5;  // Prevent infinite loops
    
    for _ in 0..max_iterations {
        // Build messages with system prompt
        let messages = build_messages(&session.messages);
        
        // Call Ollama
        let response = state.ollama.chat(&messages).await?;
        
        // Check for tool calls
        let tool_calls = parse_tool_calls(&response);
        
        if tool_calls.is_empty() {
            // No tools - this is the final response
            session.add_message(ChatMessage {
                role: Role::Assistant,
                content: response.clone(),
            });
            
            // Stream the response
            return stream_response(response);
        }
        
        // Execute tools
        for call in tool_calls {
            yield StreamEvent::ToolStart { ... };
            
            let result = execute_tool(&state, call).await;
            
            yield StreamEvent::ToolEnd { ... };
            
            // Add tool result to conversation
            session.add_message(ChatMessage {
                role: Role::Assistant,
                content: format!("{}\n\n{}", response, result.format_for_context()),
            });
        }
        
        // Loop back to call Ollama again with tool results
    }
    
    // Max iterations reached
    yield StreamEvent::Error { 
        message: "Too many tool iterations".to_string() 
    };
}
```

---

## Tool Result Formatting

### Search Results

```
[Tool Result: search]
Query: "climate change effects 2024"

1. Title: Climate Change Impacts Report 2024
   URL: https://example.org/climate-report
   Snippet: The latest data shows significant increases in...

2. Title: Effects of Climate Change on Agriculture
   URL: https://example.com/agriculture-climate
   Snippet: Farmers are experiencing unprecedented...

3. Title: Ocean Temperature Rise Accelerates
   URL: https://news.example.com/ocean-temps
   Snippet: New measurements indicate that ocean warming...
[End Tool Result]
```

### Fetch Results

```
[Tool Result: fetch]
URL: https://example.org/climate-report
Content-Type: text/html
Length: 4521 characters

Climate Change Impacts Report 2024

Executive Summary

The year 2024 has seen continued acceleration of climate-related impacts
across all continents. Key findings include:

Temperature records were broken in 47 countries...

[Content truncated at 4000 characters]
[End Tool Result]
```

### Error Results

```
[Tool Result: search]
Error: Search failed - API rate limit exceeded
[End Tool Result]
```

```
[Tool Result: fetch]
Error: Failed to fetch URL - Connection timeout after 10 seconds
[End Tool Result]
```

---

## Edge Cases

### Multiple Tools in One Response

Model might output:
```
Let me search for that and also check the official documentation.
<search>rust async streams</search>
<fetch>https://docs.rs/tokio-stream/latest</fetch>
```

Handle by executing both, collecting results, then calling model again.

### Malformed Tool Calls

If model outputs `<search>` without closing tag, or nested tags, be lenient:
- Try to extract query anyway
- Log warning
- If truly unparseable, treat as no tool call

### Empty Query

If model outputs `<search></search>`:
- Skip execution
- Optionally add error result: "Search query was empty"

### Invalid URLs

If model outputs `<fetch>not-a-url</fetch>`:
- Return error result
- Model will see the error and can try again or apologise

### Recursive Tool Calls

Model might include tool calls in response after receiving tool results (wanting to search again). This is fine — the loop handles it, up to max iterations.
