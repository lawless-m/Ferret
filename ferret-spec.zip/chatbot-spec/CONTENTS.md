# Ferret

A self-hosted chatbot with web search and page retrieval capabilities, running on your intranet. Powered by Qwen 7B, with the enthusiasm of a creature that loves digging things up.

**Personality:** Eager, curious, self-aware that it's not the biggest brain in the room. Celebrates when searches go well, apologises cheerfully when they don't. British sensibility — helpful without being sycophantic, honest about its limitations.

## Documents

| File | Description |
|------|-------------|
| [ARCHITECTURE.md](ARCHITECTURE.md) | System design and component overview |
| [API.md](API.md) | HTTP endpoints specification |
| [DATA_STRUCTURES.md](DATA_STRUCTURES.md) | Rust types and data models |
| [TOOL_SYSTEM.md](TOOL_SYSTEM.md) | Tool calling format and system prompts |
| [PROJECT_LAYOUT.md](PROJECT_LAYOUT.md) | Directory structure and file organisation |
| [DEPENDENCIES.md](DEPENDENCIES.md) | Cargo.toml and external dependencies |

## Where to Start

1. Read **ARCHITECTURE.md** first for the big picture
2. **TOOL_SYSTEM.md** explains how Qwen invokes search/fetch
3. **DATA_STRUCTURES.md** has the core Rust types
4. **API.md** defines the HTTP interface
5. **PROJECT_LAYOUT.md** shows where everything goes
6. **DEPENDENCIES.md** lists what goes in Cargo.toml

## Tech Stack

- **Axum** — HTTP server
- **HTMX** — Frontend interactivity without JS framework
- **Ollama** — Local LLM inference (Qwen 7B)
- **Brave Search API** — Web search
- **reqwest** — HTTP client for Ollama, Brave, and page fetching

## Key Design Decisions

- **No authentication** — trusted intranet
- **In-memory sessions** — no database, ephemeral
- **Streaming responses** — SSE for token-by-token output
- **ReAct-style tool use** — model outputs tool calls, backend executes, loops until done
