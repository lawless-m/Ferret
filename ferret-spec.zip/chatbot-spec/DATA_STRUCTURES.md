# Data Structures

## Core Types

### Session

```rust
use chrono::{DateTime, Utc};
use uuid::Uuid;

#[derive(Debug, Clone)]
pub struct Session {
    pub id: Uuid,
    pub messages: Vec<ChatMessage>,
    pub created_at: DateTime<Utc>,
    pub last_activity: DateTime<Utc>,
}

impl Session {
    pub fn new() -> Self {
        let now = Utc::now();
        Self {
            id: Uuid::new_v4(),
            messages: Vec::new(),
            created_at: now,
            last_activity: now,
        }
    }

    pub fn add_message(&mut self, message: ChatMessage) {
        self.messages.push(message);
        self.last_activity = Utc::now();
    }

    pub fn clear(&mut self) {
        self.messages.clear();
        self.last_activity = Utc::now();
    }
}
```

### ChatMessage

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatMessage {
    pub role: Role,
    pub content: String,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum Role {
    System,
    User,
    Assistant,
}
```

### SessionManager

```rust
use dashmap::DashMap;
use std::sync::Arc;

pub type SessionManager = Arc<DashMap<Uuid, Session>>;

pub fn create_session_manager() -> SessionManager {
    Arc::new(DashMap::new())
}
```

---

## Ollama Types

### ChatRequest (to Ollama)

```rust
#[derive(Debug, Serialize)]
pub struct OllamaChatRequest {
    pub model: String,
    pub messages: Vec<ChatMessage>,
    pub stream: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub options: Option<OllamaOptions>,
}

#[derive(Debug, Serialize)]
pub struct OllamaOptions {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub temperature: Option<f32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub num_predict: Option<i32>,
}
```

### ChatResponse (from Ollama, streaming)

```rust
#[derive(Debug, Deserialize)]
pub struct OllamaChatChunk {
    pub model: String,
    pub message: ChatMessage,
    pub done: bool,
    #[serde(default)]
    pub done_reason: Option<String>,
}
```

---

## Tool Types

### ToolCall

```rust
#[derive(Debug, Clone)]
pub enum ToolCall {
    Search { query: String },
    Fetch { url: String },
}

impl ToolCall {
    /// Parse tool calls from model output
    /// Returns (remaining_text, Vec<ToolCall>)
    pub fn parse(text: &str) -> (String, Vec<ToolCall>) {
        // Implementation parses <search>query</search> and <fetch>url</fetch>
        todo!()
    }
}
```

### ToolResult

```rust
#[derive(Debug, Clone)]
pub struct ToolResult {
    pub tool: String,
    pub success: bool,
    pub content: String,
}

impl ToolResult {
    pub fn format_for_context(&self) -> String {
        format!(
            "[Tool Result: {}]\n{}\n[End Tool Result]",
            self.tool, self.content
        )
    }
}
```

---

## Brave Search Types

### SearchRequest

```rust
pub struct BraveSearchRequest {
    pub query: String,
    pub count: u8,  // 1-20, default 10
}
```

### SearchResponse

```rust
#[derive(Debug, Deserialize)]
pub struct BraveSearchResponse {
    pub web: Option<WebResults>,
}

#[derive(Debug, Deserialize)]
pub struct WebResults {
    pub results: Vec<SearchResult>,
}

#[derive(Debug, Deserialize)]
pub struct SearchResult {
    pub title: String,
    pub url: String,
    pub description: String,
    #[serde(default)]
    pub age: Option<String>,
}

impl SearchResult {
    pub fn format_for_context(&self) -> String {
        format!(
            "Title: {}\nURL: {}\nSnippet: {}\n",
            self.title, self.url, self.description
        )
    }
}
```

---

## SSE Event Types

### StreamEvent

```rust
#[derive(Debug, Serialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum StreamEvent {
    Chunk { content: String },
    ToolStart { tool: String, query: String },
    ToolEnd { tool: String, success: bool },
    Error { message: String },
    Done,
}

impl StreamEvent {
    pub fn to_sse(&self) -> String {
        format!("data: {}\n\n", serde_json::to_string(self).unwrap())
    }
}
```

---

## Application State

### AppState

```rust
#[derive(Clone)]
pub struct AppState {
    pub sessions: SessionManager,
    pub ollama: OllamaClient,
    pub brave: BraveClient,
    pub config: AppConfig,
}

#[derive(Clone)]
pub struct AppConfig {
    pub ollama_url: String,
    pub ollama_model: String,
    pub session_timeout_mins: u64,
}
```

---

## Error Types

```rust
use thiserror::Error;

#[derive(Error, Debug)]
pub enum AppError {
    #[error("Ollama error: {0}")]
    Ollama(String),
    
    #[error("Brave search error: {0}")]
    BraveSearch(String),
    
    #[error("Page fetch error: {0}")]
    PageFetch(String),
    
    #[error("Session not found")]
    SessionNotFound,
    
    #[error("Invalid request: {0}")]
    InvalidRequest(String),
}

impl axum::response::IntoResponse for AppError {
    fn into_response(self) -> axum::response::Response {
        let status = match &self {
            AppError::SessionNotFound => StatusCode::NOT_FOUND,
            AppError::InvalidRequest(_) => StatusCode::BAD_REQUEST,
            _ => StatusCode::INTERNAL_SERVER_ERROR,
        };
        
        (status, self.to_string()).into_response()
    }
}
```
