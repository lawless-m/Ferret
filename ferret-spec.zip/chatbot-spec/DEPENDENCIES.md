# Dependencies

## Cargo.toml

```toml
[package]
name = "ferret"
version = "0.1.0"
edition = "2021"
description = "A small but eager chatbot with web search capabilities"

[dependencies]
# Web framework
axum = { version = "0.7", features = ["macros"] }
axum-extra = { version = "0.9", features = ["cookie"] }
tower = "0.5"
tower-http = { version = "0.6", features = ["fs", "cors"] }

# Async runtime
tokio = { version = "1", features = ["full"] }
tokio-stream = "0.1"
futures = "0.3"

# HTTP client
reqwest = { version = "0.12", features = ["json", "stream"] }

# Serialisation
serde = { version = "1", features = ["derive"] }
serde_json = "1"

# Session management
dashmap = "6"
uuid = { version = "1", features = ["v4", "serde"] }

# Time handling
chrono = { version = "0.4", features = ["serde"] }

# Error handling
thiserror = "2"
anyhow = "1"

# Logging
tracing = "0.1"
tracing-subscriber = { version = "0.3", features = ["env-filter"] }

# Configuration
dotenvy = "0.15"

# Tool parsing
regex = "1"
lazy_static = "1"

# HTML to text (for page fetching)
scraper = "0.21"
```

## Dependency Notes

### axum + axum-extra

Main web framework. `axum-extra` provides cookie handling which we need for session management.

### tokio + tokio-stream + futures

Async runtime and streaming primitives. Essential for SSE responses and concurrent handling.

### reqwest

HTTP client for:
- Ollama API calls
- Brave Search API calls  
- Fetching web pages

The `stream` feature enables streaming responses from Ollama.

### dashmap

Thread-safe concurrent hashmap. Better than `Arc<Mutex<HashMap>>` for this use case — less contention, no need to hold locks across await points.

### scraper

HTML parsing for extracting text from fetched pages. Uses CSS selectors. Alternative: `select.rs` or hand-rolled with `regex` (not recommended).

### tracing + tracing-subscriber

Structured logging. Better than `log` crate for async code — handles spans across await points.

### dotenvy

Load `.env` files for local development. Keeps secrets out of command line history.

---

## .env.example

```bash
# Ollama configuration
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5:7b

# Brave Search API
BRAVE_API_KEY=your-api-key-here

# Server configuration
BIND_ADDRESS=0.0.0.0:3000
SESSION_TIMEOUT_MINS=60

# Logging
RUST_LOG=info,ferret=debug
```

---

## Version Pinning

The versions above are current as of late 2024. For stability:

```toml
# Lock to exact versions if needed
axum = "=0.7.9"
tokio = "=1.42.0"
# etc.
```

Or just use `Cargo.lock` (committed to repo) to ensure reproducible builds.

---

## Optional Dependencies

### If you want templates (instead of inline HTML)

```toml
askama = "0.12"
askama_axum = "0.4"
```

### If you want more robust HTML-to-text

```toml
html2text = "0.12"
```

### If you want rate limiting

```toml
governor = "0.8"
```

### If you want metrics

```toml
metrics = "0.24"
metrics-exporter-prometheus = "0.16"
```

---

## Build Dependencies

None required. Pure Rust, compiles with standard `cargo build`.

---

## System Requirements

- Rust 1.75+ (for async trait stabilisation)
- Network access to Ollama endpoint
- Network access to Brave Search API (external)
- Network access to arbitrary URLs (for page fetching)

---

## Feature Flags (Future)

Could structure optional features:

```toml
[features]
default = ["search", "fetch"]
search = []  # Brave search integration
fetch = []   # Page fetching
metrics = ["dep:metrics", "dep:metrics-exporter-prometheus"]
```

For now, keep it simple — everything included.
