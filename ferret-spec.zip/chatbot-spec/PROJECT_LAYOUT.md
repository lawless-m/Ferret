# Project Layout

```
ferret/
├── Cargo.toml
├── Cargo.lock
├── .env.example
├── README.md
│
├── src/
│   ├── main.rs              # Entry point, server setup
│   ├── config.rs            # Configuration loading
│   ├── error.rs             # Error types
│   │
│   ├── routes/
│   │   ├── mod.rs
│   │   ├── index.rs         # GET / - serve UI
│   │   ├── chat.rs          # POST /chat - handle messages
│   │   ├── clear.rs         # POST /clear - clear session
│   │   └── health.rs        # GET /health - health check
│   │
│   ├── session/
│   │   ├── mod.rs
│   │   ├── types.rs         # Session, ChatMessage, Role
│   │   └── manager.rs       # SessionManager, cleanup task
│   │
│   ├── ollama/
│   │   ├── mod.rs
│   │   ├── client.rs        # OllamaClient
│   │   └── types.rs         # Request/response types
│   │
│   ├── tools/
│   │   ├── mod.rs
│   │   ├── parser.rs        # Tool call parsing
│   │   ├── executor.rs      # Tool execution coordinator
│   │   ├── search.rs        # Brave search implementation
│   │   └── fetch.rs         # Page fetch implementation
│   │
│   └── chat/
│       ├── mod.rs
│       ├── handler.rs       # Main chat loop logic
│       └── stream.rs        # SSE streaming helpers
│
├── templates/
│   └── index.html           # Main chat UI template
│
└── static/
    └── style.css            # Minimal styling
```

## File Responsibilities

### src/main.rs

```rust
// - Load configuration from environment
// - Create shared state (sessions, clients)
// - Set up Axum router
// - Start server
// - Optionally spawn session cleanup task
```

### src/config.rs

```rust
// - AppConfig struct
// - Load from environment variables
// - Validation
// - Defaults
```

### src/routes/

Each route handler in its own file:
- `index.rs` — Render HTML template, set session cookie
- `chat.rs` — Accept message, delegate to chat handler, return SSE stream
- `clear.rs` — Clear session messages
- `health.rs` — Check Ollama connectivity, return status

### src/session/

- `types.rs` — Session, ChatMessage, Role structs
- `manager.rs` — DashMap wrapper, get/create session, cleanup logic

### src/ollama/

- `client.rs` — HTTP client for Ollama `/api/chat` endpoint
- `types.rs` — Request/response structs matching Ollama's API

### src/tools/

- `parser.rs` — Regex-based tool call detection
- `executor.rs` — Dispatch tool calls, collect results
- `search.rs` — Brave API client
- `fetch.rs` — Page fetcher with HTML-to-text

### src/chat/

- `handler.rs` — Main loop: send to Ollama, check for tools, execute, repeat
- `stream.rs` — SSE event formatting, streaming helpers

### templates/index.html

Single HTML file with:
- HTMX script include
- Chat container
- Message input form
- Clear button
- Minimal inline JS for stream handling

### static/style.css

Basic styling:
- Chat bubble appearance
- Message alignment (user right, assistant left)
- Input styling
- Responsive layout

---

## Key Implementation Notes

### State Sharing

```rust
// In main.rs
let state = AppState {
    sessions: create_session_manager(),
    ollama: OllamaClient::new(&config.ollama_url, &config.ollama_model),
    brave: BraveClient::new(&config.brave_api_key),
    config: config.clone(),
};

// Pass to routes
let app = Router::new()
    .route("/", get(routes::index))
    .route("/chat", post(routes::chat))
    .route("/clear", post(routes::clear))
    .route("/health", get(routes::health))
    .with_state(state);
```

### Session Cookie Handling

```rust
// In index route
async fn index(
    cookies: CookieJar,
    State(state): State<AppState>,
) -> impl IntoResponse {
    let session_id = cookies
        .get("session_id")
        .and_then(|c| Uuid::parse_str(c.value()).ok())
        .unwrap_or_else(|| {
            let id = Uuid::new_v4();
            state.sessions.insert(id, Session::new(id));
            id
        });
    
    let cookies = cookies.add(
        Cookie::build(("session_id", session_id.to_string()))
            .path("/")
            .http_only(true)
            .same_site(SameSite::Strict)
    );
    
    (cookies, Html(render_template()))
}
```

### SSE Streaming

```rust
// In chat route
async fn chat(
    cookies: CookieJar,
    State(state): State<AppState>,
    Form(input): Form<ChatInput>,
) -> Sse<impl Stream<Item = Result<Event, Infallible>>> {
    let session_id = extract_session_id(&cookies);
    
    let stream = chat_handler::handle(state, session_id, input.message);
    
    Sse::new(stream).keep_alive(
        KeepAlive::new()
            .interval(Duration::from_secs(15))
            .text("keep-alive")
    )
}
```

---

## Build & Run

```bash
# Development
cargo run

# Release
cargo build --release
./target/release/ferret

# With environment
OLLAMA_URL=http://localhost:11434 \
OLLAMA_MODEL=qwen2.5:7b \
BRAVE_API_KEY=your-key-here \
cargo run
```
