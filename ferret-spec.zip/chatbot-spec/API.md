# API Specification

## Endpoints

### GET /

Serves the main chat UI.

**Response:** HTML page with chat interface

**Notes:**
- Generates new session UUID if none in cookie
- Sets `session_id` cookie (httpOnly, SameSite=Strict)
- Contains HTMX-powered chat form

---

### POST /chat

Submit a chat message and receive streaming response.

**Request Headers:**
```
Content-Type: application/x-www-form-urlencoded
Cookie: session_id=<uuid>
```

**Request Body:**
```
message=<user message text>
```

**Response Headers:**
```
Content-Type: text/event-stream
Cache-Control: no-cache
```

**Response Body (SSE stream):**
```
data: {"type": "chunk", "content": "The"}

data: {"type": "chunk", "content": " answer"}

data: {"type": "chunk", "content": " is..."}

data: {"type": "tool_start", "tool": "search", "query": "climate data"}

data: {"type": "tool_end", "tool": "search", "success": true}

data: {"type": "done"}
```

**Event Types:**

| Type | Fields | Description |
|------|--------|-------------|
| `chunk` | `content` | Token(s) from model response |
| `tool_start` | `tool`, `query` | Tool execution beginning |
| `tool_end` | `tool`, `success` | Tool execution complete |
| `error` | `message` | Error occurred |
| `done` | — | Stream complete |

**Error Responses:**
- `400 Bad Request` — Missing or empty message
- `500 Internal Server Error` — Ollama/tool failure (also sent via SSE error event)

---

### POST /clear

Clear the current session's conversation history.

**Request Headers:**
```
Cookie: session_id=<uuid>
```

**Response:**
```
200 OK
HX-Trigger: chat-cleared
```

**Notes:**
- Clears message history but keeps session
- HTMX trigger causes UI to clear chat container

---

### GET /health

Health check endpoint.

**Response:**
```json
{
  "status": "ok",
  "ollama": "connected",
  "sessions": 5
}
```

**Notes:**
- Pings Ollama to verify connectivity
- Returns session count for monitoring

---

## HTMX Integration

### Chat Form

```html
<form hx-post="/chat" 
      hx-ext="sse" 
      sse-connect="/chat" 
      sse-swap="message"
      hx-target="#chat-messages" 
      hx-swap="beforeend">
  <input type="text" name="message" required>
  <button type="submit">Send</button>
</form>
```

**Notes:**
- Uses SSE extension for streaming
- Appends chunks to chat container
- Form resets after submission

### Message Rendering

Server streams chunks that get appended. Client-side JS (minimal) handles:
- Creating message bubble on first chunk
- Appending subsequent chunks to current bubble
- Showing tool execution indicators
- Scrolling to bottom

### Clear Button

```html
<button hx-post="/clear" 
        hx-swap="none">
  Clear Chat
</button>
```

Listens for `chat-cleared` trigger to empty the chat container.

---

## Session Management

### Cookie Format

```
session_id=550e8400-e29b-41d4-a716-446655440000; Path=/; HttpOnly; SameSite=Strict
```

### Session Lifecycle

1. **Creation:** On first visit, server generates UUID v4
2. **Persistence:** Cookie maintained across page refreshes
3. **Expiry:** Session removed after `SESSION_TIMEOUT_MINS` of inactivity
4. **Manual clear:** `/clear` endpoint resets history, keeps session

### No Session Cookie

If request arrives without valid session cookie:
- Generate new session
- Set cookie in response
- Proceed normally

---

## Rate Limiting

None implemented (intranet tool). Could add simple per-session rate limiting if needed:
- Max N messages per minute
- Return 429 if exceeded
