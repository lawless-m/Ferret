# Architecture

## Overview

Ferret: a small, eager chatbot that digs up information from the web.

```
┌─────────────────────────────────────────────────────────────────┐
│                         Browser (HTMX)                          │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Axum Web Server                            │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │   Routes    │  │   Session   │  │      Tool Executor      │  │
│  │  /         │  │   Manager   │  │  ┌─────┐  ┌──────────┐  │  │
│  │  /chat     │  │  (DashMap)  │  │  │Brave│  │Page Fetch│  │  │
│  │  /stream   │  │             │  │  └─────┘  └──────────┘  │  │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Ollama (Qwen 7B)                             │
│                    http://localhost:11434                        │
└─────────────────────────────────────────────────────────────────┘
```

## Components

### 1. Axum Web Server

The main application. Serves the HTML UI and handles chat API requests.

**Responsibilities:**
- Serve static HTML/CSS
- Accept chat messages via POST
- Stream responses via SSE
- Manage session lifecycle

### 2. Session Manager

In-memory storage for conversation history, keyed by session UUID.

**Implementation:** `DashMap<SessionId, Session>` for thread-safe concurrent access.

**Session contains:**
- Conversation history (Vec of messages)
- Created timestamp
- Last activity timestamp

**Cleanup:** Optional background task to expire sessions after N minutes of inactivity. Not essential for a toy project — server restart clears everything anyway.

### 3. Ollama Client

Evolved from the provided example. Key changes:
- Add streaming support via SSE
- Add `/api/chat` endpoint support (conversation mode vs single-shot generate)

**Endpoints used:**
- `POST /api/chat` — conversation with message history, streaming

### 4. Tool Executor

Handles tool invocations detected in model output.

**Tools:**
- **search** — Query Brave Search API, return titles/snippets/URLs
- **fetch** — Retrieve page content via reqwest, extract text

**Execution loop:**
1. Send messages to Ollama
2. Collect response
3. Check for tool invocation patterns
4. If found: execute tool, append result to context, goto 1
5. If not found: stream final response to client

### 5. Brave Search Client

Simple wrapper around Brave Search API.

**Endpoint:** `GET https://api.search.brave.com/res/v1/web/search`

**Headers:** `X-Subscription-Token: <API_KEY>`

**Parameters:** `q` (query), `count` (results, default 5-10)

**Returns:** Parsed results with title, URL, description for each hit.

### 6. Page Fetcher

Retrieves and extracts text from web pages.

**Constraints:**
- Timeout: 10 seconds
- Max size: 1MB
- Text extraction only (strip HTML tags)
- No JavaScript execution

**Implementation:** reqwest with timeout, then basic HTML-to-text conversion (can use `scraper` crate or simple regex for MVP).

## Request Flow

### Chat Message Flow

```
1. User types message, submits form
2. HTMX POSTs to /chat with session_id + message
3. Server:
   a. Get/create session from DashMap
   b. Append user message to history
   c. Build prompt with system message + history
   d. Send to Ollama (streaming)
   e. Collect chunks, check for tool calls
   f. If tool call: execute, append result, loop to (d)
   g. Stream final response chunks to client via SSE
   h. Append assistant response to history
4. HTMX appends streamed response to chat container
```

### Tool Execution Flow

```
1. Model outputs: <search>climate change effects</search>
2. Parser extracts: tool=search, query="climate change effects"
3. Executor calls Brave API
4. Results formatted as context block
5. Appended to conversation: [Tool Result: search]...
6. Model called again with updated context
7. Model synthesises answer using search results
```

## Configuration

Environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `OLLAMA_URL` | Ollama API endpoint | `http://localhost:11434` |
| `OLLAMA_MODEL` | Model name | `qwen2.5:7b` |
| `BRAVE_API_KEY` | Brave Search API key | (required) |
| `BIND_ADDRESS` | Server bind address | `0.0.0.0:3000` |
| `SESSION_TIMEOUT_MINS` | Session expiry | `60` |

## Error Handling

- **Ollama unreachable:** Return error message to user, don't crash
- **Brave API failure:** Inform model search failed, let it respond without
- **Page fetch timeout:** Return partial or error to model
- **Invalid session:** Create new session transparently

## Security Considerations

This is an intranet tool with no authentication. Minimal hardening:

- Page fetch: timeout and size limits prevent resource exhaustion
- No user-supplied code execution
- Sessions are ephemeral, no persistent data
- Brave API key stored in environment, not in code
